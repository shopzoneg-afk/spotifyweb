export const RATIOS = {
  "2:3": { w: 7200, h: 10800 },
  "4:5": { w: 6000, h: 7500 }
};
